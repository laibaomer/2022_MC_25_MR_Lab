# week 1 answers

Node:
A program that does a task in ROS

Topic:
 channel to send or get messages between nodes.

 Package:
 A folder with nodes and related files.

 Sourcing:
 It telLS ros where the workspace is. Without it ROS cant find package

 Colcon Build:
 Builds your package so ROS can run them

 Entry Points:
 Make a python function usable as ros2 can run it

 