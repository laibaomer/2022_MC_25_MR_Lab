import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class CmdVelPublisher(Node):

    def __init__(self):
        super().__init__('cmd_vel_pub')

        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.timer = self.create_timer(2.0, self.callback)

        self.state = True

    def callback(self):
        msg = Twist()

        if self.state:
            msg.linear.x = 0.2
            self.get_logger().info('Forward')
        else:
            msg.linear.x = 0.0
            self.get_logger().info('Stop')

        self.pub.publish(msg)
        self.state = not self.state


def main(args=None):
    rclpy.init(args=args)
    node = CmdVelPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
