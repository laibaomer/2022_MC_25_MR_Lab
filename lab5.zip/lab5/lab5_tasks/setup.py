from setuptools import find_packages, setup

package_name = 'lab5_tasks'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='laiba',
    maintainer_email='laibaomer0406@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
    'console_scripts': [
        'cmd_vel_pub = lab5_tasks.cmd_vel_pub:main',
        'odom_sub = lab5_tasks.odom_sub:main',
    ],
},
)
