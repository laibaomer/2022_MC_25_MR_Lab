import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
import math

class TurtleFollower(Node):
    def __init__(self):
        super().__init__('turtle_follower')
        # Subscribe to Leader (Turtle 1)
        self.subscription = self.create_subscription(Pose, '/turtle1/pose', self.leader_callback, 10)
        # Subscribe to Follower (Turtle 2) to know its own position
        self.pose_subscription = self.create_subscription(Pose, '/turtle2/pose', self.follower_callback, 10)
        # Publish to Follower's velocity
        self.publisher = self.create_publisher(Twist, '/turtle2/cmd_vel', 10)
        
        self.leader_pose = None
        self.follower_pose = None

    def follower_callback(self, msg):
        self.follower_pose = msg

    def leader_callback(self, msg):
        self.leader_pose = msg
        if self.leader_pose is not None and self.follower_pose is not None:
            msg_vel = Twist()
            # Calculate distance and angle
            dx = self.leader_pose.x - self.follower_pose.x
            dy = self.leader_pose.y - self.follower_pose.y
            distance = math.sqrt(dx**2 + dy**2)
            angle_to_leader = math.atan2(dy, dx)

            # Move only if the leader is far enough away
            if distance > 1.0:
                msg_vel.linear.x = 1.5 * distance
                msg_vel.angular.z = 6.0 * (angle_to_leader - self.follower_pose.theta)
            
            self.publisher.publish(msg_vel)

def main(args=None):
    rclpy.init(args=args)
    node = TurtleFollower()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
