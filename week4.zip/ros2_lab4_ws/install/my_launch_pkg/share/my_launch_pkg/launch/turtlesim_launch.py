from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess, TimerAction

def generate_launch_description():
    return LaunchDescription([

        # 🐢 Simulator
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='sim'
        ),

        # 🎮 Teleop turtle1
        Node(
            package='turtlesim',
            executable='turtle_teleop_key',
            name='teleop1',
            prefix='xterm -e'
        ),

        # 🧬 Spawn turtle2 using service (after delay)
        TimerAction(
            period=2.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/spawn',
                        'turtlesim/srv/Spawn',
                        "{x: 2.0, y: 2.0, theta: 0.0, name: 'turtle2'}"
                    ],
                    output='screen'
                )
            ]
        ),

        # 🎮 Teleop turtle2
        Node(
            package='turtlesim',
            executable='turtle_teleop_key',
            name='teleop2',
            remappings=[
                ('/turtle1/cmd_vel', '/turtle2/cmd_vel')
            ],
            prefix='xterm -e'
        ),
    ])
