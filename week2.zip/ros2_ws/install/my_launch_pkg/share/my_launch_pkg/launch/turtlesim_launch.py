from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import TimerAction, ExecuteProcess

def generate_launch_description():

    return LaunchDescription([

        # 🐢 TurtleSim node
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='sim',
            output='screen'
        ),

        # ⏳ Spawn second turtle using SERVICE (correct way)
        TimerAction(
            period=2.0,
            actions=[
                ExecuteProcess(
                    cmd=[
                        'ros2', 'service', 'call',
                        '/spawn',
                        'turtlesim/srv/Spawn',
                        "{x: 2.0, y: 2.0, theta: 0.0, name: 'turtle2'}"
                    ],
                    output='screen'
                )
            ]
        ),

    ])

