import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist

class Follower(Node):

    def __init__(self):
        super().__init__('follower')

        self.sub = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.callback,
            10
        )

        self.pub = self.create_publisher(
            Twist,
            '/turtle2/cmd_vel',
            10
        )

    def callback(self, msg):
        cmd = Twist()

        # simple follow logic
        cmd.linear.x = 1.5

        # steer based on angle of leader
        cmd.angular.z = 4.0 * msg.theta

        self.pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = Follower()
    rclpy.spin(node)
    rclpy.shutdown()
