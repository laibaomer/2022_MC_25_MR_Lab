#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time


class VelocityPublisher(Node):

    def __init__(self):
        super().__init__('velocity_publisher')

        self.publisher_ = self.create_publisher(
            Twist, 'turtle1/cmd_vel', 10
        )

        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.step = 0
        self.count = 0

    def timer_callback(self):
        msg = Twist()

        # Move forward
        msg.linear.x = 2.0
        msg.angular.z = 0.0
        self.publisher_.publish(msg)
        time.sleep(2)

        # Turn
        msg.linear.x = 0.0
        msg.angular.z = 2.09
        self.publisher_.publish(msg)
        time.sleep(1)


def main(args=None):
    rclpy.init(args=args)

    velocity_publisher = VelocityPublisher()
    rclpy.spin(velocity_publisher)

    velocity_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
