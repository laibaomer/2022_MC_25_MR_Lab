import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math

class GoToPoseNode(Node):
    def __init__(self):
        super().__init__('go_to_pose_node')
        
        # Publisher to move the turtle
        self.publisher_ = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        
        # Subscriber to get current position
        self.subscription = self.create_subscription(Pose, 'turtle1/pose', self.pose_callback, 10)
        
        self.current_pose = Pose()
        self.target_x = 15.0  # Set your target X here
        self.target_y = 15.0  # Set your target Y here
        
        # Timer to run the control loop
        self.timer = self.create_timer(0.1, self.move_to_target)
        self.get_logger().info(f"Moving to target: {self.target_x}, {self.target_y}")

    def pose_callback(self, msg):
        self.current_pose = msg

    def get_distance(self):
        return math.sqrt(math.pow((self.target_x - self.current_pose.x), 2) +
                         math.pow((self.target_y - self.current_pose.y), 2))

    def move_to_target(self):
        msg = Twist()
        distance = self.get_distance()

        if distance > 0.1:
            # 1. Linear velocity (speed proportional to distance)
            msg.linear.x = 1.5 * distance 

            # 2. Angular velocity (turn towards the target)
            goal_theta = math.atan2(self.target_y - self.current_pose.y, 
                                    self.target_x - self.current_pose.x)
            diff = goal_theta - self.current_pose.theta
            
            # Normalize angle to keep it between -pi and pi
            if diff > math.pi: diff -= 2*math.pi
            if diff < -math.pi: diff += 2*math.pi
            
            msg.angular.z = 4.0 * diff
        else:
            # Target reached
            msg.linear.x = 0.0
            msg.angular.z = 0.0
            self.get_logger().info("Target Reached!")
            self.timer.cancel()

        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = GoToPoseNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
